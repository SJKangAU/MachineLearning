The Project directory contains the following files:
-->Project (Folder)
  --> Report.pdf (PDF File version of Report)
  --> Toxicity Classification in Online Comments.ipynb (Jupyter File of Assignment)
  --> Toxicity Classification in Online Comments.pdf (PDF Version of Jupyter File)
  --> Readme.txt



In order to implement the code of the task you need to open the "Toxicity Classification in Online Comments.ipynb" file,
and execute the code cells to get the results of the program.